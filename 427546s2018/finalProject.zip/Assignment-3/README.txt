Name: Rohan Girase. 

Email Address- rohan_girase@student.uml.edu

Computer Graphics Assignment 3.

Steps:-

1.	Open ComputerGraphicsA3.html file. 
2. 	You will be able to see three views.




References:
http://www.html5canvastutorials.com/tutorials/html5-canvas-lines/
http://www.arungudelli.com/html5/html5-canvas-polygon/
