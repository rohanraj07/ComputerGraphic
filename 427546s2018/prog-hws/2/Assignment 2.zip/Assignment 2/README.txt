Name: Rohan Girase. 

Email Address- rohan_girase@student.uml.edu

Computer Graphics Assignment 2.

Steps:-

1. Open the file Question1.html for question 1.

2. Enter all values as per requirement.

3. Click on GetFractalShape button.

4. Open the file Question2.html for question 2.

5. Enter all values as per requirement.

6. Click on GetShapeOfTheWheel button.

I have implemented the program using Html 5 ,CSS and using script tags.

The Program works fine in Safari and Google Chrome Browser.

The user is able to draw line, circle, ellipse by asking for coordinate inputs 

for the figures.

References:
http://www.html5canvastutorials.com/tutorials/html5-canvas-lines/
http://www.arungudelli.com/html5/html5-canvas-polygon/
