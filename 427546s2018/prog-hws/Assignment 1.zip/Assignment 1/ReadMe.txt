Name: Rohan Girase. 

Email Address- rohan_girase@student.uml.edu

Computer Graphics Assignment 1.

Steps:-

1. Open the file index.html.

2. Click on each link to draw that kind of a figure


I have implemented the program using Html 5 ,CSS and using script tags.

The Program works fine in Safari and Google Chrome Browser.

The user is able to draw line, circle, ellipse by asking for coordinate inputs 

for the figures.

References:
http://www.html5canvastutorials.com/tutorials/html5-canvas-lines/
http://www.arungudelli.com/html5/html5-canvas-polygon/
